const appName = "Foodie";
const pageOneTitle = "Page One";
const pageTwoTitle = "Page Two";


const pageTwoRoute = "pageTwo";